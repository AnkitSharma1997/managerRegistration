package com.cognizant.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Manager;

@Repository
public class ManagerDao {

	public boolean checkCredentilas(String uname, String pass){
		Manager manager2;
		SessionFactory sf = new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session = sf.openSession();
		try{
		Transaction tx = session.beginTransaction();
		
		manager2 = (Manager) session.get(Manager.class, uname);
		System.out.println(uname+"    "+ pass+"   "+manager2);
		System.out.println(" manager2 \n Name :- "+manager2.getManager_first_name()+"\n"+"Password :- "+manager2.getManager_password());
		tx.commit();
		if(manager2.getManager_first_name().equals(uname) && manager2.getManager_password().equals(pass))
		{
			//System.out.println("manager info  id"+manager.getManager_id()+"   is null maybe  "+manager.getManager_first_name());
			return true;					
		}
		}catch(Exception e){
			System.out.println(e);
		}
		return false;
	}
	
	public void addManagerDetails(Manager manager){
		
		SessionFactory sf = new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		session.persist(manager);
		
		tx.commit();
		
	}
}
