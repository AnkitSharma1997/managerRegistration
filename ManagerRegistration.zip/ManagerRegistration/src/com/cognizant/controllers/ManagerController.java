package com.cognizant.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cognizant.dao.ManagerDao;
import com.cognizant.entity.Manager;


@Controller
public class ManagerController {

	ManagerDao managerDao = new ManagerDao();
	
	@RequestMapping("/")
	public String display(){
		return "index";
	}
	
	@RequestMapping("managerReg.html")
	public String viewRegistrationPage(@ModelAttribute("manager") Manager manager){
		System.out.println(manager);
		managerDao.addManagerDetails(manager);
		return "index";
	}
	
	@RequestMapping("managerView")
	public String viewManager(@ModelAttribute("manager") Manager manager){
		System.out.println("Name :- "+manager.getManager_first_name()+"\n"+"Password :- "+manager.getManager_password());
		//System.out.println(managerDao.checkCredentilas(manager.getManager_first_name(), manager.getManager_password()));
		if(managerDao.checkCredentilas(manager.getManager_first_name(), manager.getManager_password()))
			return "managerView";
		return "index";
	}
	
	@RequestMapping("managerReg")
	public String viewManagerReg(){
		return "managerRegistration";
	}

	@ModelAttribute("manager")
	public Manager managerObject(){
		Manager  manager = new Manager();
		return manager;
	}
	
}
